<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Backup</title>
    </head>
    <body>
        <h1>Bienvenu dans le nowhere du backup!</h1>  
        <h2>Sauver le site!</h2>
        <form action="./save.php">
            <input type="submit" value="Save" />
        </form>


        <h2>Charger le site</h2>
        <form action="./load.php">
            <input type="submit" value="Load" />
        </form>
    </body>
</html>